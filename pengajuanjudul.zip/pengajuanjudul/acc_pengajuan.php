<?php
	session_start();
    include 'koneksi.php';
	  if($_SESSION['status_prodi'] != true){
		echo '<script>window.location="login_prodi.php"</script>';
	}

  $id_pengajuan = $_GET['id_pengajuan'];
  
  $status = 'selesai';

    $acc = mysqli_query($conn, "UPDATE pengajuan SET 
                status = '".$status."'
                WHERE id_pengajuan = '".$id_pengajuan."' ");

    if($acc){
      echo '<script>alert("Pengajuan di ACC!")</script>';
      echo '<script>window.location="tanggapan.php"</script>';
    }else{
      echo 'Gagal'.mysqli_error($conn);
    }

?>