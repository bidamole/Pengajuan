<?php
	session_start();
    include 'koneksi.php';
	  if($_SESSION['status_prodi'] != true){
		echo '<script>window.location="login_prodi.php"</script>';
	}

  $id_pengajuan = $_GET['id_pengajuan'];
  
  $status = 'proses';

    $tolak = mysqli_query($conn, "UPDATE pengajuan SET 
                status = '".$status."'
                WHERE id_pengajuan = '".$id_pengajuan."' ");

    if($tolak){
      echo '<script>alert("Proses Pengajuan Success!")</script>';
      echo '<script>window.location="tanggapan.php"</script>';
    }else{
      echo 'Gagal'.mysqli_error($conn);
    }

?>