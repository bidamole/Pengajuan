<?php
	session_start();
    include 'koneksi.php';
	  if($_SESSION['status_prodi'] != true){
		echo '<script>window.location="login_prodi.php"</script>';
	}

    $id_prodi = $_SESSION['id_prodi'];
    $prodi = mysqli_query($conn, "SELECT * FROM prodi 
            WHERE id_prodi = '$id_prodi'
    ");
    $dos = mysqli_fetch_array($prodi);

?>

<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Data Pengajuan</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-0evHe/X+R7YkIZDRvuzKMRqM+OrBnVFBL6DOitfPri4tjfHxaWutUpFmBp4vmVor" crossorigin="anonymous">
  </head>
  <body class="bg-light">
  
  <div class="container-fluid">
      <div class="container-fluid">
        <br><br>
      <div class="row py-3 text-center">
          <div class="col-lg-12">
                <h3>Data Pengajuan Mahasiswa</h3>
          </div>
      </div>

      <div class="row">
          <div class="col-lg-12">
              <div class="table-responsive">
                  <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>NIM</th>
                                <th>Nama</th>
                                <th>Tanggal Pengajuan</th>
                                <th>Isi Laporan</th>
                                <th>Tanggapan</th>
                                <th>Status</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php 
							$pengajuan = mysqli_query($conn, "SELECT pengajuan.*, mahasiswa.nama 
                            FROM pengajuan
                            LEFT JOIN mahasiswa ON pengajuan.nim = mahasiswa.nim
                        ");
                            $no = 1;
							if(mysqli_num_rows($pengajuan) > 0){
							while($jud = mysqli_fetch_array($pengajuan)){
				            ?>
                            <tr>
                                <td><?php echo $no++ ?></td>
                                <td><?php echo $jud['nim'] ?></td>
                                <td><?php echo $jud['nama'] ?></td>
                                <td><?php echo $jud['tgl_pengajuan'] ?></td>
                                <td><?php echo $jud['isi_laporan'] ?></td>
                                <td><?php echo $jud['status'] ?></td>
                                
                                <?php if($jud['status'] == '0') {?>
                                <th>Belom Di Proses</th>
                                <?php }elseif($jud['status'] == '1') { ?>
                                <th>Proses</th>
                                <?php }elseif($jud['status'] == '2') {?>
                                <th>Selesai</th>
                                <?php } ?>

                                <?php if($jud['status'] == '0') { ?>
                                <th>
                                <a href="acc_pengajuan.php?id_pengajuan=<?php echo $jud['id_pengajuan'] ?>" class="btn btn-primary btn-sm" onclick="return confirm('Ingin pengajuan mahasiswa selesai?')">Selesai</a>
                                <a href="proses_pengajuan.php?id_pengajuan=<?php echo $jud['id_pengajuan'] ?>" class="btn btn-info btn-sm" onclick="return confirm('Ingin pengajuan mahasiswa dalam proses?')">Proses</a>
                                </th>
                                <?php }else{ ?>
                                    <?php if($jud['status'] == '0') {?>
                                    <th>Belom Di Acc</th>
                                    <?php }elseif($jud['status'] == '1') { ?>
                                    <th>Dalam Proses</th>
                                    <?php }elseif($jud['status'] == '2') {?>
                                    <th>Selesai</th>
                                    <?php } ?>
                                    <?php }?>
                            </tr>  
                            <?php }}else{ ?>
							<tr>
								<td colspan="9" class="text-danger">Belom ada data pengajuan!</td>
							</tr>

				            <?php } ?>
                        </tbody>
                  </table>
              </div>
          </div>
      </div>

      <div class="row">
          <div class="col-lg-12">
              <a href="dashboard_prodi.php" class="btn btn-danger btn-sm">Back to Dashboard Prodi</a>
          </div>
      </div>

      </div>
  </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/js/bootstrap.bundle.min.js" integrity="sha384-pprn3073KE6tl6bjs2QrFaJGz5/SUsLqktiwsUTF55Jfv3qYSDhgCecCxMW52nD2" crossorigin="anonymous"></script>
  </body>
</html>