<?php
session_start();
include 'koneksi.php';
if($_SESSION['status_prodi'] != true){
    echo '<script>window.location="login_prodi.php"</script>';
}

$id_pengajuan = $_SESSION['id_pengajuan'];

$pengajuan = mysqli_query($conn, "SELECT * FROM pengajuan WHERE id_pengajuan = '$id_pengajuan' ");
$mhs = mysqli_fetch_array($pengajuan);
?>

<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Data Tanggapan</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-0evHe/X+R7YkIZDRvuzKMRqM+OrBnVFBL6DOitfPri4tjfHxaWutUpFmBp4vmVor" crossorigin="anonymous">
  </head>
  <body class="bg-light">
  
  <div class="container-fluid">
      <div class="container">
        <br><br>
      <div class="row py-3 text-center">
          <div class="col-lg-12">
                <h3>Data Tanggapan</h3>
          </div>
      </div>

      <div class="row">
          <div class="col-lg-12">
              <div class="table-responsive">
                  <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Pengajuan</th>
                                <th>Tanggal Tanggapan</th>
                                <th>Tanggapan</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php 
                            // Query untuk mengambil data pengajuan
							$tanggapan = mysqli_query($conn, "SELECT * FROM tanggapan WHERE id_pengajuan = '$id_pengajuan'");
                            $no = 1;
							if(mysqli_num_rows($tanggapan) > 0){
							    while($data = mysqli_fetch_array($tanggapan)){
				            ?>
                            <tr>
                                <td><?php echo $no++ ?></td>
                                <td><?php echo $data['id_pengajuan'] ?></td>
                                <td><?php echo $data['tgl_tanggapan'] ?></td>
                                <td><?php echo $data['tanggapan'] ?></td>
                                <td>
                                    <?php 
                                    if($data['status'] == '0') {
                                        echo 'Belum Diproses';
                                    } elseif($data['status'] == 'proses') {
                                        echo 'Proses';
                                    } elseif($data['status'] == 'selesai') {
                                        echo 'Selesai';
                                    }
                                    ?>
                                </td>
                            </tr>  
                            <?php }} else { ?>
							<tr>
								<td colspan="5" class="text-danger">Anda belum melakukan tanggapan!</td>
							</tr>
				            <?php } ?>
                        </tbody>
                  </table>
              </div>
          </div>
      </div>

      </div>
  </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/js/bootstrap.bundle.min.js" integrity="sha384-pprn3073KE6tl6bjs2QrFaJGz5/SUsLqktiwsUTF55Jfv3qYSDhgCecCxMW52nD2" crossorigin="anonymous"></script>
  </body>
</html>