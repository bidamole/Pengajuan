<?php

	include '../koneksi.php ';

	if(isset($_GET['nim'])){

		$delete = mysqli_query($conn, "DELETE FROM mahasiswa WHERE nim = '".$_GET['nim']."' ");
		echo '<script>window.location="mahasiswa.php"</script>';

	}

?>