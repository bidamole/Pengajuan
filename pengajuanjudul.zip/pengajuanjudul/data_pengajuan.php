<?php
session_start();
include 'koneksi.php';
if($_SESSION['status_mahasiswa'] != true){
    echo '<script>window.location="login_mahasiswa.php"</script>';
}

$nim = $_SESSION['nim'];

$mahasiswa = mysqli_query($conn, "SELECT * FROM mahasiswa WHERE nim = '$nim' ");
$mhs = mysqli_fetch_array($mahasiswa);
?>

<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Data Pengajuan <?php echo $mhs['username'] ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-0evHe/X+R7YkIZDRvuzKMRqM+OrBnVFBL6DOitfPri4tjfHxaWutUpFmBp4vmVor" crossorigin="anonymous">
  </head>
  <body class="bg-light">
  
  <div class="container-fluid">
      <div class="container">
        <br><br>
      <div class="row py-3 text-center">
          <div class="col-lg-12">
                <h3>Data Pengajuan <?php echo $mhs['username'] ?></h3>
          </div>
      </div>

      <div class="row">
          <div class="col-lg-12">
              <div class="table-responsive">
                  <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Isi Laporan</th>
                                <th>Tanggal Pengajuan</th>
                                <th>Foto</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php 
                            // Query untuk mengambil data pengajuan
							$pengajuan = mysqli_query($conn, "SELECT * FROM pengajuan WHERE nim = '$nim'");
                            $no = 1;
							if(mysqli_num_rows($pengajuan) > 0){
							    while($data = mysqli_fetch_array($pengajuan)){
				            ?>
                            <tr>
                                <td><?php echo $no++ ?></td>
                                <td><?php echo $data['isi_laporan'] ?></td>
                                <td><?php echo $data['tgl_pengajuan'] ?></td>
                                <td>
                                    <?php if($data['foto'] != NULL) { ?>
                                        <img src="path/to/foto/<?php echo $data['foto'] ?>" alt="Foto" width="100">
                                    <?php } else { ?>
                                        Tidak ada foto
                                    <?php } ?>
                                </td>
                                <td>
                                    <?php 
                                    if($data['status'] == '0') {
                                        echo 'Belum Diproses';
                                    } elseif($data['status'] == 'proses') {
                                        echo 'Proses';
                                    } elseif($data['status'] == 'selesai') {
                                        echo 'Selesai';
                                    }
                                    ?>
                                </td>
                            </tr>  
                            <?php }} else { ?>
							<tr>
								<td colspan="5" class="text-danger">Anda belum melakukan pengajuan!</td>
							</tr>
				            <?php } ?>
                        </tbody>
                  </table>
              </div>
          </div>
      </div>

      <div class="row">
          <div class="col-lg-12">
              <a href="dashboard_mahasiswa.php" class="btn btn-danger btn-sm">Back to Dashboard Mahasiswa</a>
          </div>
      </div>

      </div>
  </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/js/bootstrap.bundle.min.js" integrity="sha384-pprn3073KE6tl6bjs2QrFaJGz5/SUsLqktiwsUTF55Jfv3qYSDhgCecCxMW52nD2" crossorigin="anonymous"></script>
  </body>
</html>